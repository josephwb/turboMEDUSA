## Only used for base model
medusaMLFitBase <- function (z, sp, model, fixedEpsilon, criterion)
{
	fit <- getOptimalModelFlavour(partition.id=1, z=z, sp=sp, model=model, criterion=criterion);
	model.fit <- calculateModelFit(fit=fit, z=z);
	
	return(list(par=matrix(fit$par, nrow=1, dimnames=list(NULL,c("r", "epsilon"))), lnLik.part=fit$lnLik, lnLik=fit$lnLik,
		split.at=min(z[,"anc"]), aic=round(model.fit[1], digits=7), aicc=round(model.fit[2], digits=7), num.par=model.fit[3],
		cut.at="node", model=fit$model));
}

fit <- medusaMLFitBase(z=z, sp=sp, model=model, criterion=criterion);

getOptimalModelFlavour <- function (partition.id, z, sp, model, criterion)
{
	fit.bd <- NULL;
	fit.yule <- NULL;
	
	if (model == "yule" | model == "mixed")
	{
		fit.yule <- medusaMLFitPartition(partition.id, z, sp=sp, model="yule");
		fit.yule$model <- "yule";
	}
	if (model == "bd" | model == "mixed")
	{
		if (is.na(sp[2])) {sp[2] <- 0.5;}
		fit.bd <- medusaMLFitPartition(partition.id, z, sp=sp, model="bd");
		fit.bd$model <- "bd";
	}
## Figure out which model fits best
	if (is.null(fit.bd))
	{
		fit <- fit.yule;
	} else if (is.null(fit.yule)) {
		fit <- fit.bd;
	} else {
## Considering both places for a shift
	#	cat("Comparing bd and yule here.\n")
		fit.bd.val <- calculateModelFit(fit=fit.bd, z=z);
		fit.yule.val <- calculateModelFit(fit=fit.yule, z=z);
		
		if (criterion == "aic") {element <- 1;} else {element <- 2;}
		
		if (fit.bd.val[[element]] < fit.yule.val[[element]])
		{
			fit <- fit.bd;
		} else {
			fit <- fit.yule;
		}
	}
	return(fit);
}