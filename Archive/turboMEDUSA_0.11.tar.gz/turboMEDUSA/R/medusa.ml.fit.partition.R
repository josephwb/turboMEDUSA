medusa.ml.fit.partition <-
function(partition, z, sp=c(0.1, 0.05))
{
# Construct likelihood function:
	lik <- make.lik.medusa.part(z[z[,"partition"] == partition,,drop=FALSE])
	
	fit <- optim(fn=lik, par=sp, method="N", control=list(fnscale=-1))
	list(par=fit$par, lnLik=fit$value)
}

