calculate.model.weights <-
function (fit)
{
	best <- min(fit)
	delta <- fit-best
	sumDelta <- sum(exp(-0.5 * delta))
	w <- (exp(-0.5 * delta)/sumDelta)
	
	results <- data.frame(fit=fit,delta=delta,w=w)
	
	return(results)
}

