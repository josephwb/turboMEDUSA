prune.tree.merge.data <-
function(phy, richness, verbose=TRUE)
{
# Rename exemplar taxa with taxon name in richness file
	if (!is.null(richness$exemplar))
	{
# Change relevant tip.labels in phy; individual 'exemplar' may be NA, use original tip.label.
# Ordering in richness file should NOT be assumed to match order of tip.labels
		i.na <- is.na(richness$exemplar)
		phy$tip.label[match(richness$exemplar[!i.na], phy$tip.label)] <- as.character(richness$taxon[!i.na])
	}
	
	if (length(phy$tip.label) != length(richness[,1]))
	{
# Prune tree down to lineages with assigned richnesses
		temp <- richness[, "n.taxa"]
		names(temp) <- richness[, "taxon"]
		pruned <- treedata(phy, temp, warnings=verbose)  # geiger function calling ape (namecheck)
		phy <- pruned$phy
# Check the tree
	#	plotNN(phy)					# Node numbers (ape-style) plotted
	}
	return(list(phy=phy, richness=richness))
}

