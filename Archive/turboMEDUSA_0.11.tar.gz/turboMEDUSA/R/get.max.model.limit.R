get.max.model.limit <-
function(richness, model.limit, stop, verbose)
{
	samp.size <- (2*length(richness[,1]) - 1)
	
	max.model.limit <- as.integer(samp.size/3) - ((!samp.size %% 3) * 1)
	if (stop == "model.limit")
	{
		if (model.limit > max.model.limit) {model.limit <- max.model.limit}
		if (verbose) {cat("\nLimiting consideration to ", model.limit, " piecewise BD models\n\n", sep="")}
	} else if (stop == "threshold") {
		model.limit <- max.model.limit
		if (verbose) {cat("\nConsidering a maximum of ", model.limit, " piecewise BD models (or until threshold is not satisfied)\n\n", sep="")}
	}
	
	return(model.limit)
}

