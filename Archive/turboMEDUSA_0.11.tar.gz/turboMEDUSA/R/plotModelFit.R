plotModelFit <-
function (all.res)
{
	ylim <- c(min(all.res[,"aic"],all.res[,"aicc"]), max(all.res[,"aic"],all.res[,"aicc"]))
	plot(all.res[,"N.Models"],all.res[,"aicc"], xlab="Number of Piecewise Models", ylab="Model Fit", ylim=ylim, type="l", col="blue")
	points(all.res[,"N.Models"],all.res[,"aicc"], col="blue", pch=21, bg="white")
	points(all.res[,"N.Models"],all.res[,"aic"], col="black", type="l")
	points(all.res[,"N.Models"],all.res[,"aic"], col="black", pch=21, bg="white")
	
	legend("topleft", c("aicc","aic"), pch=21, pt.bg="white", lty=1, col=c("blue", "black"), inset = .05, cex=0.75, bty="n") # 'bottomright' also works
}

