medusa.ml.prefit <-
function(node, z, anc, initial.r, initial.e)
{
	obj <- medusa.split(node, z, anc)
	z <- obj$z
# Partition '2' represents the clade/edge of interest
	fitted <- medusa.ml.fit.partition(2, z, sp=c(initial.r, initial.e))
	
	return(fitted)
}

