calculate.model.fit.summary <-
function (models, phy, plotFig, fig.title=NULL, ...)
{
	tmp <- matrix(nrow=(length(models)), ncol=6)
	colnames(tmp) <- c("N.Models", "Break.Node", "Ln.Lik", "N.Param", "aic", "aicc")
	
	w.aic <- numeric(length(models))
	w.aicc <- numeric(length(models))
	
	for (i in 1:length(tmp[,1]))
	{
		tmp[i,] <- c(i, as.integer(models[[i]]$split.at[i]), models[[i]]$lnLik, models[[i]]$num.par, models[[i]]$aic, models[[i]]$aicc)
	}
	
	all.res <- as.data.frame(tmp)
	all.res[1,2] <- NA # root node for base model
	
	w.aic <- calculate.model.weights(all.res$aic)
	w.aicc <- calculate.model.weights(all.res$aicc)
	
	all.res <- cbind(all.res[,c(1:5)], w.aic=w.aic$w, aicc=all.res$aicc, w.aicc=w.aicc$w)
	
	if (plotFig)
	{
		dev.new()
		plotModelFit(all.res)
		if (!is.null(fig.title)) {title(main=fig.title, cex.main=0.75)}
	}
	return(all.res)
}

