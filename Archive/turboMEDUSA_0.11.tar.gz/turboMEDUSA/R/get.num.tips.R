get.num.tips <-
function(node, phy)
{
	n <- length(node.leaves(phy,node))
	return(n)
}

