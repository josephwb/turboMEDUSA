medusa.split <-
function(node, z, anc)
{
	part <- z[,"partition"]
	base <- min(part[z[,1] == node | z[,2] == node])
	tag <- max(part) + 1

	i <- anc[[node]]
	idx <- i[part[i] == base]
	z[idx,"partition"] <- tag
	
	z[which(z["dec"] == node),"partition"] <- tag # Possible to have several edges to consider

	list(z=z, affected=c(unique(part[idx]), tag))
}

