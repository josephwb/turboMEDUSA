get.threshold <-
function (x)
{
	a = -3.5941052380332650E+01
	b =  6.7372587299747000E+00
	c = -1.0061508340754866E-01
	Offset =  2.7516678664333408E+01
	y <- a * (x-b)^c + Offset
	return(y)
}

