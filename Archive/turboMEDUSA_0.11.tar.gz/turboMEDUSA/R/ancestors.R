ancestors <-
function(node, all.edges)
{
	ans <- node
	repeat
	{
		node <- all.edges[all.edges[,1] %in% node,2]
		if (length(node) > 0) {ans <- c(ans, node)} else {break}
	}
	unlist(ans)
}

