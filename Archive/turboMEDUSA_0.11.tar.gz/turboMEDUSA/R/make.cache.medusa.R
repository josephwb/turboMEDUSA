make.cache.medusa <-
function(phy, richness, mc, num.cores)
{
	n.tips <- length(phy$tip.label)
	n.int <- nrow(phy$edge) - n.tips
	
## Ape numbers the tips first
	i.int <- seq_len(n.int)
	interior <- phy$edge[,2] %in% phy$edge[,1]
	bt <- branching.times(phy)
	
# Consider only internal edges first
	edges.int <- phy$edge[interior,]
	colnames(edges.int) <- c("anc", "dec")
	
	t.0 <- bt[match(edges.int[,1], (n.tips+1):max(edges.int))]
	t.1 <- c(t.0[i.int] - phy$edge.length[interior])
	
	z.internal <- cbind(edges.int, t.0, t.1, t.len=t.0 - t.1,
		n.0=rep(1, n.int), n.t=rep(NA, n.int))
	
# Now, pendant edges; 
	edges.pendant <- phy$edge[match(seq_len(n.tips), phy$edge[,2]),]
	colnames(edges.pendant) <- c("anc", "dec")
	
	t.0 <- bt[match(edges.pendant[,1], (n.tips+1):max(edges.pendant))]
	t.1 <- rep(0, n.tips)
# cannot assume richness ordering necessarily matches that of tip labels
	ext.richness <- richness$n.taxa[match(phy$tip.label, richness$taxon)]
	
	z.pendant <- cbind(edges.pendant, t.0, t.1, t.len=t.0 - t.1,
		n.0=rep(1, n.tips), n.t=ext.richness)
	
	z <- rbind(z.internal, z.pendant)
	z <- cbind(z,partition=rep(1, length(z[,1]))) # Stores piecewise model structure
	rownames(z) <- NULL
	
# Used for identifying ancestral nodes below i.e. tracking breakpoints
	all.edges <- as.matrix(z[,c("anc","dec")])
	
	if (mc)
	{
		list(z=z, anc=mclapply(seq_len(max(all.edges)), ancestors.idx, all.edges), mc.cores=num.cores)
	} else {
		list(z=z, anc=lapply(seq_len(max(all.edges)), ancestors.idx, all.edges))
	} # And, we're good to go...
}

