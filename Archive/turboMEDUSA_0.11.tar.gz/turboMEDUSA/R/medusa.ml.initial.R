medusa.ml.initial <-
function(z, initial.r, initial.e)
{
	rootnode <- min(z[,"anc"])
	obj <- medusa.ml.fit.partition(1, z, sp=c(initial.r, initial.e))
	
	model.fit <- calculate.model.fit(fit=obj, z)
	
	list(par=matrix(obj$par, nrow=1, dimnames=list(NULL,c("r", "epsilon"))), lnLik.part=obj$lnLik, 
	   lnLik=obj$lnLik, split.at=rootnode, aic=model.fit[1], aicc=model.fit[2], num.par=model.fit[3])
}

