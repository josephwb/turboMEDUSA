medusa.ml.update <-
function(node, z, anc, fit, tips, virgin.nodes, num.tips, root.node)
{
	obj <- medusa.split(node, z, anc)
	z <- obj$z
	aff <- obj$affected
	
	op <- fit$par
	sp <- op[aff[1],] # Use previously fit parameter values from clade that is currently being split
	
	fit1 <- medusa.ml.fit.partition(aff[1], z, sp)
	fit2 <- 0
	
## Check if pendant; calculations already done
	if (node < root.node)
	{
		fit2 <- tips[[node]]
## Check if virgin node; save more time!
	} else if (length(unique(z[(z[,"partition"] == aff[2] & z[,"dec"] < root.node),"dec"])) == num.tips[[node]])
	{
		fit2 <- virgin.nodes[[node - root.node]]
## Novel arrangement; need to calculate
	} else {
		fit2 <- medusa.ml.fit.partition(aff[2], z, sp)
	}
	
	op[aff[1],] <- fit1$par # Replace parameters with new values for diminished clade
	fit$par <- rbind(op, fit2$par)
	fit$lnLik.part[aff] <- c(fit1$lnLik, fit2$lnLik) # Replace parameters with new values for diminished clade
	fit$split.at <- c(fit$split.at, node)
	fit$lnLik <- sum(fit$lnLik.part)
	
	model.fit <- calculate.model.fit(fit, z)
	
	fit$aic <- model.fit[1]
	fit$aicc <- model.fit[2]
	fit$num.par <- model.fit[3]
	
	return(fit)
}

